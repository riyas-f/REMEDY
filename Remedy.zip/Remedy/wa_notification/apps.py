from django.apps import AppConfig


class WaNotificationConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'wa_notification'
